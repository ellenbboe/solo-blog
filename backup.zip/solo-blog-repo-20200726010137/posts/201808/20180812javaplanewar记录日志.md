title: 2018-08-12 java plane war记录日志
date: '2018-08-12 19:39:17'
updated: '2018-08-12 19:39:17'
tags: [日志]
permalink: /articles/2018/08/12/1561009685130.html
---
之前旧的游戏没有完成,里面用的是timer.schdule
本次重新写打算用thread
现在还没有想好使用什么方法写子弹和敌人(是不是上一次一样使用list)
linux下似乎swing的绘制有点卡,不知道是什么问题....

还有就是遇到了linux下workbanch闪退的问题
解决方法是: `rm -rf .mysql/workbench/`

![](https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=2775041432,3653689496&fm=11&gp=0.jpg)