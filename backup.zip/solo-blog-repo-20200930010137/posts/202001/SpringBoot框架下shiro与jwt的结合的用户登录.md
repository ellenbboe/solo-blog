title: SpringBoot框架下shiro与jwt的结合的用户登录
date: '2020-01-10 01:07:12'
updated: '2020-01-11 15:20:06'
tags: [shiro, jwt]
permalink: /articles/2020/01/10/1578589632211.html
---
![](https://img.hacpai.com/bing/20171111.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

写了一次使用 shiro 和 jwt 的用户登录(没有涉及到用户权限的控制),下面进行很简单的技术总结
![](https://i02piccdn.sogoucdn.com/9521cda69f999094)
之前使用的是 Redis 中保存用户信息，使用 uuid-用户信息的键值对来判断用户登录

现在可以通过 shiro 来控制用户登录，使用 jwt 进行 no-session 方式进行验证登录，通过 jwt 同时生成用于用户刷新的 refreshtoken 和 token 来进行用户单点的验证(shiro 也有单点的验证功能)

---
我简单的总结了一下
用户登录分为下面几种情况

1. 浏览界面时 token 未过期

   > 正常浏览
   >
2. 浏览界面时 token 过期，refreshToken 没有过期

   > 正常浏览，返回新的 token,生成新的 refreshToken
   >
3. 浏览界面时 token 过期，refreshToken 过期

   > 返回登录界面，清除 cookie 中的 token
   >
4. 登录时 token 未过期

   > 正常登录
   >
5. 登录时 token 过期，refreshToken 没有过期

   > 正常浏览，返回新的 token,生成新的 refreshToken
   >
6. 登录时 token 过期，refreshToken 过期

   > 通过数据库判断用户信息
   >
7. 浏览时 token 未过期但与 refreshToken 不匹配

   > 重新登录
   >
8. 登录时 token 未过期但与 refreshToken 不匹配

   > 通过数据库判断用户信息
   >

其他的话 shiro 和 jwt 的配置就写了这么 5 个，基本上搜索一下都能写出来
![image.png](https://img.hacpai.com/file/2020/01/image-bb062a3e.png)
值得提一下的是 shiro 会拦截 js,css 这些文件，需要在配置 shiroConfig 中放行，还有就是把添加的 filter 写在最下面
还是很简单的，是我太菜了
![](https://i03piccdn.sogoucdn.com/829115f2c4c66943)
