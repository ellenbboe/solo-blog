title: git基本操作
date: '2018-07-10 23:53:14'
updated: '2018-07-10 23:53:14'
tags: [git]
permalink: /articles/2018/07/10/1561009675261.html
---
#### 一般提交操作为:
```
git add -all ==>  gaa
git commit -m "xxxx" ==> gc
git pull ==>   gl
git push  ==>  gp
```
#### 自动保存密码:
`git config --global credential.helper store`