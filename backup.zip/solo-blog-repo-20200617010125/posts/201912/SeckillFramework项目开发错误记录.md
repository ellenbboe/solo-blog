title: SeckillFramework项目开发错误记录
date: '2019-12-09 19:07:35'
updated: '2020-01-20 12:37:51'
tags: [日志, 笔记, 异常, 总结]
permalink: /articles/2019/12/09/1575889655832.html
---
![](https://img.hacpai.com/file/2020/01/thumb1920590466-2eb4fae0.png "thumb1920590466.png")

An error happened during template parsing (template: "class path resource [templates/login.html]" - line 34, col 18)

原因：由于添加了 type="tel",删除恢复

---
@mapping 出错

原因：系统错误，没事

---
Property 'configuration' and 'configLocation' can not specified with together

在 application.properties 中重复使用 MyBatis 配置(已经有了 mybatis-config 文件),将 mybatis.configuration 开头的配置删掉

---
org.xml.sax.SAXParseException; lineNumber: 3; columnNumber: 16; 文档根元素 "configuration" 必须匹配 DOCTYPE 根 "null"

原因：XML 中没有开头

---
返回时没有加@Responsebody 发生找不到页面的错误

---
Error updating database. Cause: java.sql.SQLSyntaxErrorException: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'order

( user_id,

goods_id,

orde' at line 1

2019-12-16 14:58:32.360 DEBUG 8692 --- [ main] sf.dao.OrderMapper.insertSelective : ==> Preparing: insert into order ( user_id, goods_id, order_status, order_time ) values ( ?, ?, ?, ? )

2019-12-16 14:58:32.425 DEBUG 8692 --- [ main] sf.dao.OrderMapper.insertSelective : ==> Parameters: 1(Integer), 1(Integer), 0(Integer), 2019-12-16 14:58:31.921(Timestamp)

---
表的名称不能使用 order 之类的

---
数据库保存的时间不是上传的时间 时区处理

&serverTimezone=Asia/Shanghai

---
Field 'id' doesn't have a default value

数据库 id 改成自增

---
The requested version 1.7.16 by your slf4j binding is not compatible with xxxx

slf4j 的版本升到 1.7.16 解决

---
@slf4j 未生效

在 idea 中添加插件 lomok,在 pom.xml 中引入依赖

---
nested exception is org.apache.ibatis.executor.ExecutorException: No constru

在实体类中添加不加参数的构造函数即可

---
[org.springframework.data.redis.serializer.SerializationException: Could not read JSON: Cannot construct instance of `sf.model.UserModel` (no Creators, like default construct, exist):

在 model 中假如构造函数

---
java.lang.IllegalArgumentException: SimpleMessageConverter only supports String, byte[] and Serializable payloads, received: sf.mq.OrdMessage

将对象转换成 JSON 字符串进行传输

---
浏览器 返回上一页之后强行刷新一次

<script type="text/javascript">
    if(window.name != "a"){
         location.reload();
         window.name = "a";
     }else{
         window.name = "";
      }
</script>

maven 项目依赖 reimport 无法导入，镜像也已经是国内的了

到 maven repo 中删除前面的顶级包在重新导入

---
aop 切面不起作用

在声明的时候后缀是 aj(当初声明的时候用了切面的类),改为 Java 后缀 正常运行

---
java.lang.ClassCastException

类型转换出错 比如 string 无法转换成 list

---
WRONGTYPE Operation against a key holding the wrong kind of value

Redis 中使用了错误的操作模式，或者说是保存了错误的类型

---
ERR value is not an integer or out of range

Redis 中对 string 进行了 decr -.-(保存的时候把 int 保存成了 string

---
SpringBoot 项目无法使用 127.0.0.1 进行访问，用 localhost
