title: fork函数的简单记录
date: '2018-10-21 22:38:07'
updated: '2018-10-21 22:38:07'
tags: [日志]
permalink: /articles/2018/10/21/1561009674771.html
---
#### 关于操作系统fork的记录

由于`fork()`出来的子进程与父进程时并行执行的,所以在父进程结束后子进程还有可能存在(如果不让父进程等待子进程结束的话)

**单次执行的代码**
```c
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
int main(){
    int p1,p2;
    while((p1=fork())==-1);
    if(p1==0){
        putchar('b');
    }else{
        while((p2=fork())==-1);
        if(p2==0){
            putchar('c');
        }else{
            putchar('a');
        }
    }
    return 0;
}

```

由于不会在c里面写多次执行的方法,所以改用`shell`脚本调用可执行文件

```bash
for((a=0;a<10000;a++))
do
        ./a.out
        sleep 1
        echo -e "\n"
done
```
`sleep`主要是为了等本程序子进程执行完,不留到下一程序输出,测试一下还是有用的


**ubuntu结果**:
```
2150
    2 abc
 2147 acb
    1 bac
    1 bca
```
**arch结果**:
```
2150
2007 abc
  52 acb
  90 bac
   1 cab
```

**结论**:主要是系统的进程调度问题,在不同系统里面出现不同结果,是一个概率事件呢...我之前还以为是固定的=.=