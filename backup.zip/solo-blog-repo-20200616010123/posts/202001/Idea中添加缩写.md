title: Idea中添加缩写
date: '2020-01-10 21:57:19'
updated: '2020-01-11 15:19:56'
tags: [idea]
permalink: /articles/2020/01/10/1578664639048.html
---
![](https://img.hacpai.com/bing/20180223.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

使用 slf4j 使老是需要添加这么一长串代码，着实不符合我程序员的风范

 `private static final Logger log = LoggerFactory.getLogger(LoginController.class);` 
于是就需要开动脑筋，能偷懒则偷懒。缩写是个好的选择 😆
![](https://i02piccdn.sogoucdn.com/9521cda69f999094)

### 第一步

![image.png](https://img.hacpai.com/file/2020/01/image-dd98b976.png)

### 第二步

![image.png](https://img.hacpai.com/file/2020/01/image-6280d3c4.png)

### 第三步

![image.png](https://img.hacpai.com/file/2020/01/image-d936dafd.png)

### 完成

![](https://i02piccdn.sogoucdn.com/24d7f7721691c23b)
