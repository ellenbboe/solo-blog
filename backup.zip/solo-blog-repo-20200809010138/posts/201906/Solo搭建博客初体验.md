title: Solo搭建博客初体验
date: '2019-06-20 15:37:07'
updated: '2019-06-27 11:33:27'
tags: [Solo]
permalink: /articles/2019/06/20/1561016227435.html
---
首先
建立数据库
`CREATE DATABASE IF NOT EXISTS solo DEFAULT CHARSET utf8mb4 COLLATE utf8_general_ci;`

安装docker
`wget -qO- https://get.docker.com/ | sh` [菜鸟教程](https://www.runoob.com/docker/ubuntu-docker-install.html)

拉取镜像
```
docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="root" \
    --env JDBC_PASSWORD="???" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=8080 --server_scheme=https --server_host=zdone.top  --server_port=
```
certbot clone下来
`./certbot-auto certonly --standalone --email 邮箱  -d 域名`
然后安装nginx
编写nginx配置文件nginx.conf
```
 upstream backend {

      server localhost:8080;
 }
 server {
         listen 80;
         server_name zdone.top www.zdone.top;
         rewrite ^(.*)$ https://$host$1 permanent;
     }
 server {
  listen 443 ssl;
      server_name  zdone.top www.zdone.top;
  if ($host ~* www.zdone.top) { 
       rewrite ^/(.*)$ https://zdone.top/$1 permanent; 
  }
access_log off;
          ssl_certificate /root/2389470_www.zdone.top_nginx/2389470_www.zdone.top.pem;
        ssl_certificate_key /root/2389470_www.zdone.top_nginx/2389470_www.zdone.top.key;
ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!MD5:!RC4:!DHE;

  ssl_session_timeout 10m;
      location / {
   proxy_pass http://backend$request_uri;
            proxy_set_header Host $host:$server_port;
            proxy_set_header X-Real-IP  $remote_addr;
            proxy_set_header http_x_forwarded_for $remote_addr;
          client_max_body_size  30m;
      }

 }    
```
这里将www.zdone.top 转向了zdone.top -.- 控制访问的域名
之后开启nginx就好了

我遇到的:
latke配置错误:重新弄了一遍docker 将ip都改成域名(已备案)就好了
nginx nginx.pid failed错误:nginx -c /etc/nginx/nginx.conf

通过crontab自动更新solo
域名可以通过供应商的免费ssl设置