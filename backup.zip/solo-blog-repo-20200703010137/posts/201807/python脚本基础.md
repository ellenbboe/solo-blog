title: python脚本基础
date: '2018-07-11 00:33:46'
updated: '2018-07-11 00:33:46'
tags: [基础]
permalink: /articles/2018/07/11/1561009675020.html
---
数组类型`tuple `字典类型`dict`
使用`*tuple`解析数组
使用`**dict`解析字典
传参数的时候 单个字符,数字由`*args`接受,形成`tuple`
键值对有`**kwargs`接受,形成`dict`
主函数`  if __name__ == '__main__'`
当然也可以使用`sys.argv`来读取参数