title: git上传脚本
date: '2018-07-11 18:40:30'
updated: '2018-07-11 18:40:30'
tags: [git]
permalink: /articles/2018/07/11/1561009673468.html
---
由于上传命令太多了,所以写了脚本
命名为comgit
```
#!/bin/bash
git add --all;git commit -m "$1";git pull;git push;
```
使用方法 `comgit "comment"`