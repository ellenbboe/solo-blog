title: Mysql远程连接
date: '2019-06-24 09:52:54'
updated: '2019-06-24 09:52:54'
tags: [Mysql]
permalink: /articles/2019/06/24/1561341174589.html
---
阿里云系统ubuntu16.04
1.将/etc/mysql/mysql.conf.d/mysqld.cnf中的bind-address注释掉
2.进入mysql,输入命令 GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY '123456' WITH GRANT OPTION;
3.输入FLUSH PRIVILEGES;
4.确保防火墙中有3306端口
大功告成