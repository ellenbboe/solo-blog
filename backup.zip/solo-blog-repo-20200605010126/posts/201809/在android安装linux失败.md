title: 在android安装linux 失败
date: '2018-09-15 18:40:39'
updated: '2018-09-15 18:40:39'
tags: [日志]
permalink: /articles/2018/09/15/1561009671768.html
---
失败原因:
三星note2 N7100 的 kernel版本太低
实验推迟 ........


![](/images/biaoqingbao/2.jpg)