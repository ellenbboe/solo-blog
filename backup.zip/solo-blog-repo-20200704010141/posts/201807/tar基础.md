title: tar基础
date: '2018-07-14 16:24:45'
updated: '2018-07-14 16:24:45'
tags: [linux]
permalink: /articles/2018/07/14/1561009684338.html
---
记录:

来自网上
  ```
  1、*.tar 用 tar -xvf 解压

  2、*.gz 用 gzip -d或者gunzip 解压

  3、*.tar.gz和*.tgz 用 tar -xzf 解压

  4、*.bz2 用 bzip2 -d或者用bunzip2 解压

  5、*.tar.bz2用tar -xjf 解压

  6、*.Z 用 uncompress 解压

  7、*.tar.Z 用tar -xZf 解压

  8、*.rar 用 unrar e解压

  9、*.zip 用 unzip 解压
```
我一般解压都是直接使用tar -xvf xxx
这样比较省事吧 (=\ _ \ =)

然后压缩就是直接使用 tar -cvf xxx 了

加入有大小需求的话,我会考虑加上z,j之类的