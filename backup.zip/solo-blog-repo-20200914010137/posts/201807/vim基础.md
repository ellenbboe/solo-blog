title: vim基础
date: '2018-07-11 00:06:17'
updated: '2018-07-11 00:06:17'
tags: [linux]
permalink: /articles/2018/07/11/1561009670406.html
---
ctrl + s 卡死后使用 ctrl + q

z回车 将光标所在行移动到屏幕顶端 

z. 将光标所在行移动到屏幕中间 

z- 将光标所在行移动到屏幕低端