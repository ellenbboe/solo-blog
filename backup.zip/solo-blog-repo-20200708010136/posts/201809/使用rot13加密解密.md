title: 使用rot13加密解密
date: '2018-09-06 03:03:53'
updated: '2018-09-06 03:03:53'
tags: [算法]
permalink: /articles/2018/09/06/1561009683535.html
---
### 使用ROT13加密解密
ROT13（回转13位）是一种简易的替换式密码算法。它是一种在英文网络论坛用作隐藏八卦、妙句、谜题解答以及某些脏话的工具，目的是逃过版主或管理员的匆匆一瞥。ROT13 也是过去在古罗马开发的凯撒密码的一种变体。ROT13是它自身的逆反，即：要还原成原文只要使用同一算法即可得，故同样的操作可用于加密与解密。该算法并没有提供真正密码学上的保全，故它不应该被用于需要保全的用途上。它常常被当作弱加密示例的典型。

应用ROT13到一段文字上仅仅只需要检查字母顺序并取代它在13位之后的对应字母，有需要超过时则重新绕回26英文字母开头即可。A换成N、B换成O、依此类推到M换成Z，然后串行反转：N换成A、O换成B、最后Z换成M（如图所示）。只有这些出现在英文字母里的字符受影响；数字、符号、空白字符以及所有其他字符都不变。替换后的字母大小写保持不变。

### 代码区:
主要思想:
将所有的字符向后移动13位就行了,但要保持大写和小写
其余其他字符不变

加密与解密是相同的函数

**加密与解密:**
```
def encrypt_rot13():
    src=input("输入加密字符串:")
    result = ""
    for x in src:
        if(x.isalpha()):
            if(x.isupper()):
                x = ord(x)+13
                if(x>90):
                    x=x-26
            else:
                x = ord(x)+13
                if(x>122):
                    x=x-26
            result = result + chr(x)
        else:
            result = result + x
    return result
```
**运行过程**
**加密**
![](/images/forpost/encrypt_rot13.png)
**解密**
![](/images/forpost/decrypt_rot13.png)

### linux下使用加密rot13加密解密
#### 加密:
`tr 'A-Za-z' 'N-ZA-Mn-za-m' <<< "The Quick Brown Fox Jumps Over The Lazy Dog"`
#### 解密:
`echo "The Quick Brown Fox Jumps Over The Lazy Dog" |tr 'N-ZA-Mn-za-m' 'A-Za-z'`