title: css渐变动画
date: '2018-07-10 23:47:23'
updated: '2018-07-10 23:47:23'
tags: [css]
permalink: /articles/2018/07/10/1561009674502.html
---
#### 鼠标放上去渐变
```
div
{
width:100px;
transition: width 2s;
-moz-transition: width 2s; /* Firefox 4 */
-webkit-transition: width 2s; /* Safari 和 Chrome */
-o-transition: width 2s; /* Opera */
}
```
#### 使div居中:
    要设置div的宽度
    再使用margin 0 auto设置