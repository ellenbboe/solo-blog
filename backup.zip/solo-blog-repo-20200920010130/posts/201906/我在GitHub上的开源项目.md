title: 我在 GitHub 上的开源项目
date: '2019-06-20 11:05:08'
updated: '2019-06-20 11:05:08'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [ellenbboe.github.io](https://github.com/ellenbboe/ellenbboe.github.io) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ellenbboe/ellenbboe.github.io/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/ellenbboe/ellenbboe.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ellenbboe/ellenbboe.github.io/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.unblog.top`](https://www.unblog.top "项目主页")</span>

Static Site Blog



---

### 2. [SeckillFramework](https://github.com/ellenbboe/SeckillFramework) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ellenbboe/SeckillFramework/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/ellenbboe/SeckillFramework/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ellenbboe/SeckillFramework/network/members "分叉数")</span>

SeckillFramework Design



---

### 3. [Right](https://github.com/ellenbboe/Right) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ellenbboe/Right/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/ellenbboe/Right/stargazers "收藏数")&nbsp;&nbsp;[🖖`2`](https://github.com/ellenbboe/Right/network/members "分叉数")</span>

Casual game(休闲小游戏)



---

### 4. [note](https://github.com/ellenbboe/note) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ellenbboe/note/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/ellenbboe/note/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ellenbboe/note/network/members "分叉数")</span>

笔记库



---

### 5. [SpringLearn](https://github.com/ellenbboe/SpringLearn) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ellenbboe/SpringLearn/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ellenbboe/SpringLearn/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ellenbboe/SpringLearn/network/members "分叉数")</span>





---

### 6. [sosoalgorithm](https://github.com/ellenbboe/sosoalgorithm) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ellenbboe/sosoalgorithm/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ellenbboe/sosoalgorithm/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ellenbboe/sosoalgorithm/network/members "分叉数")</span>

有趣的算法,有趣吗?不有趣



---

### 7. [Basic_java](https://github.com/ellenbboe/Basic_java) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ellenbboe/Basic_java/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ellenbboe/Basic_java/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ellenbboe/Basic_java/network/members "分叉数")</span>

java基地



---

### 8. [BasicWebpage](https://github.com/ellenbboe/BasicWebpage) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ellenbboe/BasicWebpage/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ellenbboe/BasicWebpage/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ellenbboe/BasicWebpage/network/members "分叉数")</span>

不可描述的前端功底-.-



---

### 9. [nodejs-learn](https://github.com/ellenbboe/nodejs-learn) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ellenbboe/nodejs-learn/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ellenbboe/nodejs-learn/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ellenbboe/nodejs-learn/network/members "分叉数")</span>

你包教,我包会



---

### 10. [awesomeWM](https://github.com/ellenbboe/awesomeWM) <kbd title="主要编程语言">Lua</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ellenbboe/awesomeWM/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ellenbboe/awesomeWM/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ellenbboe/awesomeWM/network/members "分叉数")</span>

awesomeWM config

