title: 安装Rabbitmq
date: '2020-01-08 14:19:31'
updated: '2020-01-08 14:20:41'
tags: [rabbitmq]
permalink: /articles/2020/01/08/1578464371766.html
---
### 安装 erlang 和 erlang-nox

```
apt-get install erlang erlang-nox
```

### 安装 rabbitmq-server

```
apt-get install rabbitmq-server
```

### 安装 Web 端界面

```
rabbitmq-plugins enable rabbitmq_management
```

### 添加用户(远程访问)

```bash
rabbitmqctl add_user 用户名 密码
rabbitmqctl set_user_tags 用户名 administrator
rabbitmqctl  set_permissions  -p  '/'  用户名 '.' '.' '.'
```

这是第一次安装 rabbitmq,系统在安装完成后自动启动 rabbitmq,不用再 systemctl 启动服务，当时以为启动不了，结果等了 Web 端发现已经启动了
